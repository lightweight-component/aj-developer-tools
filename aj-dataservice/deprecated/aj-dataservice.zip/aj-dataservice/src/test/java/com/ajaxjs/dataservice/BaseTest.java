package com.ajaxjs.dataservice;

public abstract class BaseTest {
}
