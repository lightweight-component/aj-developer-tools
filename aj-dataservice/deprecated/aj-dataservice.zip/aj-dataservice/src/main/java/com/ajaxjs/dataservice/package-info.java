/**
 * AJ DataService
 */
package com.ajaxjs.dataservice;