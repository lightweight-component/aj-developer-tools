/**
 * DataService 实现
 */
package com.ajaxjs.dataservice.core;