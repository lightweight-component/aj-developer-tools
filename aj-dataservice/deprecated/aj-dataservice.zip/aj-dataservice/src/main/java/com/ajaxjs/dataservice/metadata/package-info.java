/**
 * Database metadata query
 */
package com.ajaxjs.dataservice.metadata;