/**
 * 通用实体快速的 CRUD。这个服务无须 DataService。提供默认 CRUD 的逻辑，包含常见情况的 SQL。
 */
package com.ajaxjs.dataservice.crud;