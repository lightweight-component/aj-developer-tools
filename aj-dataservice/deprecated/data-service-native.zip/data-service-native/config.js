// 数据服务 UI 配置
DS_CONFIG = {
    API_ROOT: 'http://127.0.0.1:8888/iam',
};